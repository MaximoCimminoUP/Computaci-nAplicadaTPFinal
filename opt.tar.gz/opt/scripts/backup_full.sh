#!/bin/bash

# mostrar la ayuda
mostrar_ayuda() {
  echo "Este script realiza un backup del directorio origen en el directorio destino."
  echo "Uso: $0 <directorio_origen> <directorio_destino>"
  echo "Ejemplo: $0 /etc /backup_dir"
  echo "Opciones adicionales: -h para mostrar esta ayuda"
}

# verificar si se pasó -h 
if [ "$#" -eq 1 ] && [ "$1" == "-h" ]; then
  mostrar_ayuda
  exit 0
fi

# verificar que se proporcionen los argumentos
if [ "$#" -lt 2 ]; then
  echo "Error: Se requieren al menos dos argumentos."
  mostrar_ayuda
  exit 1
fi

DIRECTORIO_ORIGEN="$1"
DIRECTORIO_DESTINO="$2"
FECHA=$(date +%Y%m%d)

# validar el directorio origen 
if [ ! -d "$DIRECTORIO_ORIGEN" ]; then
  echo "Error: El directorio origen '$DIRECTORIO_ORIGEN' no existe o no está montado."
  exit 1
fi

# validar el directorio destino 
if [ ! -d "$DIRECTORIO_DESTINO" ]; then
  echo "Error: El directorio destino '$DIRECTORIO_DESTINO' no existe o no está montado."
  exit 1
fi

NOMBRE_ARCHIVO=$(basename "$DIRECTORIO_ORIGEN")bkp$FECHA.tar.gz
RUTA_ARCHIVO="$DIRECTORIO_DESTINO/$NOMBRE_ARCHIVO"

# realizar el backup
tar -czf "$RUTA_ARCHIVO" "$DIRECTORIO_ORIGEN" 2>/dev/null

# Verificar si el backup fue exitoso
if [ $? -eq 0 ]; then
  echo "Backup realizado en '$RUTA_ARCHIVO'."
else
  echo "Error!!! No se pudo realizar el backup."
  exit 1
fi
